//
//  AvatarExplorerTests.m
//  AvatarExplorerTests
//
//  Created by Ben Scheirman on 3/20/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AvatarExplorerTests.h"


@implementation AvatarExplorerTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in AvatarExplorerTests");
}

@end
