//
//  AvatarExplorerTests.h
//  AvatarExplorerTests
//
//  Created by Ben Scheirman on 3/20/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface AvatarExplorerTests : SenTestCase {
@private
    
}

@end
